var friends = [{
    "name": "Ahmed",
    "age": 25,
    "scores": [
        5,
        1,
        4,
        4,
        5,
        1,
        2,
        5,
        4,
        1
    ]
},
{
    "name": "Patrick",
    "age": 30,
    "scores": [
        5,
        4,
        2,
        2,
        4,
        3,
        1,
        1,
        5,
        5
    ]
},
{
    "name": "Steve",
    "age": 60,
    "scores": [
        5,
        5,
        2,
        3,
        2,
        5,
        5,
        4,
        4,
        2
    ]
},
{
    "name": "Jake",
    "age": 42,
    "scores": [
        5,
        3,
        3,
        3,
        3,
        2,
        5,
        5,
        4,
        1
    ]
},
{
    "name": "Jacob",
    "age": 34,
    "scores": [
        3,
        2,
        2,
        5,
        5,
        3,
        4,
        1,
        1,
        2
    ]
},
{
    "name": "Tony",
    "age": 90,
    "scores": [
        1,
        1,
        1,
        5,
        4,
        2,
        2,
        3,
        2,
        5
    ]
},
{
    "name": "Ezekiel",
    "age": 30,
    "scores": [
        5,
        2,
        5,
        2,
        1,
        4,
        2,
        1,
        2,
        3
    ]
}];

module.exports = friends;


